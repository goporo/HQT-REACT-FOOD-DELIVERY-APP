import Routers from "./routes/Routers";

function App() {
  return (
    <Routers />
  )
}

export default App;
