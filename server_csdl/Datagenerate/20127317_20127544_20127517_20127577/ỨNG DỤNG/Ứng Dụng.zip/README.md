# HQT-REACT-FOOD-DELIVERY-APP

customer: localhost:3000 </br>
business: localhost:3001 </br>
business: localhost:3002 </br>
staff: localhost:3003 </br>
shipper: localhost:3004 </br>
