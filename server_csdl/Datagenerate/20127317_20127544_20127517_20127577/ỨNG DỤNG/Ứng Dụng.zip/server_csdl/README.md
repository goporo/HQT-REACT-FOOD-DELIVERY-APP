# HQT-REACT-FOOD-DELIVERY-APP
Food DB là file tổng hợp
Thứ tự chạy
Lược đồ
Tài Khoản
Ngân hàng
QUẢN TRỊ VIÊN
NHÂN VIÊN
ĐỐI TÁC
CHI NHÁNH
TÀI XẾ 
KHÁCH HÀNG
CỬA HÀNG
HỢP ĐỒNG
HỢP ĐỒNG CHI TIẾT
HỢP ĐỒNG CHI NHÁNH
LOẠI ẨM THỰC
THỰC ĐƠN
ĐƠN HÀNG
để connect
tạo user trong mssql với tất cả quyền truy cập (DBFood, 123456)
trong sql server configuration
    đảm bảo tất cả SQL server service is running (SQL server browser)
    SQL server network thì turn on tcp/ip
    nhớ đổi lại tên server