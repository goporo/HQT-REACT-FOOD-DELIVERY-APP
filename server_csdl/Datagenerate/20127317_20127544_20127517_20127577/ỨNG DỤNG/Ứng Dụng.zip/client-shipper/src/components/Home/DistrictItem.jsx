const District = ({ d }) => {
    return (
        <option value={d.id}>{d.name}</option>
    );
};

export default District;
