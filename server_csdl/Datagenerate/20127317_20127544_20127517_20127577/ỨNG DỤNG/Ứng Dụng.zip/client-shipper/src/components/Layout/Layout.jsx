import Routers from "../../routes/Routers";

const Layout = () => {
    return (
        <>
            <Routers />
        </>
    );
};

export default Layout;
