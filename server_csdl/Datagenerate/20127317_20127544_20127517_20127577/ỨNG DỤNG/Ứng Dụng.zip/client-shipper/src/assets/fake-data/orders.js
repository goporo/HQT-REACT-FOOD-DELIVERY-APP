const orders = [
    {
      id: "order_1",
      title: "HD0001",
      date: "2022-12-05",
      state: 1,
    },
    {
      id: "order_2",
      title: "HD0002",
      date: "2022-02-15",
      state: 0,
    },
    {
      id: "order_3",
      title: "HD0003",
      date: "2022-09-23",
      state: 1,
    },
    {
      id: "order_4",
      title: "HD0004",
      date: "2022-12-09",
      state: 1,
    },
    {
      id: "order_5",
      title: "HD0005",
      date: "2022-03-09",
      state: 0,
    },
    {
      id: "order_6",
      title: "HD0006",
      date: "2022-07-05",
      state: 0,
    },
    {
      id: "order_7",
      title: "HD0007",
      date: "2022-01-06",
      state: 1,
    },
  ]

export default orders;