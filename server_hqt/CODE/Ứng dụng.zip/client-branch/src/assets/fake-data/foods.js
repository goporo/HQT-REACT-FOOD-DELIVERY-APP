const foods = [
    {
      id: "food_1",
      title: "Bún bò nạm gân",
      price: 40000,
      rating: 4.3,
      image: "/images/NamGan.jpg",
    },
    {
      id: "food_2",
      title: "Bún bò tái",
      price: 35000,
      rating: 4.3,
      image: "/images/Tai.jpg",
    },
    {
      id: "food_3",
      title: "Bún bò tái nạm",
      price: 40000,
      rating: 4.3,
      image: "/images/TaiNam.jpg",
    },
    {
      id: "food_4",
      title: "Bún bò nạm",
      price: 35000,
      rating: 4.3,
      image: "/images/Nam.jpg",
    },
    {
      id: "food_5",
      title: "Bún bò thập cẩm",
      price: 45000,
      rating: 4.3,
      image: "/images/TaiNam.jpg",
    },
    {
      id: "food_6",
      title: "Bún bò đặc biệt",
      price: 50000,
      rating: 4.3,
      image: "/images/DacBiet.jpg",
    },
  {
    id: "food_7",
    title: "Trà gừng",
    price: 20000,
    rating: 4.3,
    image: "/images/TraGung.jpg",
  },
  ]
  
  export default foods;
  