const foods = [
    {
        id: "food_1",
        title: "chicken burger",
        number: 1,
        price: 80.0,
        supplier: "the-alley",
    },
    {
        id: "food_2",
        title: "chicken deluxe fry",
        number: 3,
        price: 150.0,
        supplier: "the-alley",
    },
    {
        id: "food_3",
        title: "chicken malai gravy",
        number: 2,
        price: 200.0,
        supplier: "the-alley",
    },
    {
        id: "food_4",
        title: "chicken pizza",
        number: 1,
        price: 400.0,
        supplier: "the-alley",
    },
    {
        id: "food_5",
        title: "chicken sate",
        number: 1,
        price: 100.0,
        supplier: "the-alley",
    },
    {
        id: "food_6",
        title: "fried rice",
        number: 1,
        price: 150.0,
        supplier: "the-alley",
    },
    {
        id: "food_7",
        title: "nachos galore",
        number: 1,
        price: 120.0,
        supplier: "the-alley",
    },
    {
        id: "food_8",
        title: "pasta",
        number: 1,
        price: 120.0,
        supplier: "the-alley",
    },
    {
        id: "food_9",
        title: "ramen",
        number: 1,
        price: 80.0,
        supplier: "the-alley",
    },
    {
        id: "food_10",
        title: "noodles",
        number: 1,
        price: 70.0,
        supplier: "the-alley",
    },
  ]

export default foods;
