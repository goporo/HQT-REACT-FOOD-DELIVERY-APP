const district = [
    {
        id: "district_1",
        name: "District 1",
    },
    {
        id: "district_2",
        name: "District 3",
    },
    {
        id: "district_3",
        name: "District 4",
    },
    {
        id: "district_4",
        name: "District 5",
    },
    {
        id: "district_5",
        name: "District 6",
    },
    {
        id: "district_6",
        name: "District 7",
    },
    {
        id: "district_7",
        name: "District 8",
    },
    {
        id: "district_8",
        name: "District 10",
    },
    {
        id: "district_9",
        name: "District 11",
    },
    {
        id: "district_10",
        name: "District 12",
    },
    {
        id: "district_11",
        name: "District Binh Thanh",
    },
    {
        id: "district_12",
        name: "District Binh Tan",
    },
    {
        id: "district_13",
        name: "District Go vap",
    },
    {
        id: "district_14",
        name: "District Phu Nhuan",
    },
    {
        id: "district_15",
        name: "District Tan Binh",
    },
    {
        id: "district_16",
        name: "District Tan Phu",
    },
    {
        id: "district_17",
        name: "Thu Duc City",
    },
]

export default district;