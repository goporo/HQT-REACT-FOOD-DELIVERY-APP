﻿
--T1: tài xế A cập nhật tình trạng đơn hàng
exec sp_CapNhat_DH_TX 'DELIVERING', '1', '1'







