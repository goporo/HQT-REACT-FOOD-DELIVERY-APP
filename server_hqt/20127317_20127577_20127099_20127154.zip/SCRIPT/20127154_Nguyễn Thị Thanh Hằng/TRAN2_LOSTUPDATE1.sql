﻿
--T2: tài xế B cập nhật tình trạng đơn hàng (cùng 1 đơn với tài xế A)
exec sp_CapNhat_DH_TX 'DELIVERING', '2', '1'