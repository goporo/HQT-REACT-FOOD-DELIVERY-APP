﻿--T2: Khách hàng xem dnah sách món ăn của chi nhánh
exec sp_MonAn_ChiNhanh '1'


