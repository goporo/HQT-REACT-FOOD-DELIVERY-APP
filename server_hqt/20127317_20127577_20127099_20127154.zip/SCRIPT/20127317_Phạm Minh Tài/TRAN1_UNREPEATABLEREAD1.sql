USE QL_BANHANG_TRANHCHAP
--select * from DON_DH
--update DON_DH set TRANGTHAIDH='AVAILABLE'
exec sp_CapNhat_DH_CN 'CANCELED','1','1'
